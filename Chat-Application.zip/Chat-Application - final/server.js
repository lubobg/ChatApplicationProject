const fs = require('fs');

var express = require('express');
var app = express();
var server = require('http').createServer(app);
var io = require('socket.io').listen(server);
var bodyParser = require('body-parser');
var bcrypt = require('bcrypt');

users = [];
connections = [];
var userStore = {}; // In-memory store for user data
var chatStore = []; // Add this line to create the chatStore array
const { Pool } = require('pg');

const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'chat',
  password: 'Khoinguyen0126',
  port: 5432,
});

pool.query('SELECT * FROM chat_history ORDER BY id', (error, results) => {
    if (error) {
      throw error;
    }
    chatStore = results.rows.map(row => ({msg: row.content, user: row.username}));

  });

pool.query('SELECT * FROM user_table', (error, results) => {
    if (error) {
      throw error;
    }
    results.rows.forEach(row => {
      const username = row.username;
      const password = row.password;
      if (username && password) {
        userStore[username] = { password };
      }
    });
  });

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
server.listen(process.env.PORT || 3000);
console.log('Server Started . . .');

app.get('/', function(req, res){
    res.sendFile(__dirname + '/index.html');
});

io.sockets.on('connection', function(socket){

    // Connect Socket
    connections.push(socket);
    console.log('Connected: %s sockets connected', connections.length);
    socket.emit('load all messages', chatStore);
    pool.query('SELECT * FROM user_table', (error, results) => {
        if (error) {
          throw error;
        }
        results.rows.forEach(row => {
          const username = row.username;
          const password = row.password;
          if (username && password) {
            userStore[username] = { password };
          }
        });
      });


    // Disconnect
    socket.on('disconnect', function(data){
        if(socket.username){
            users.splice(users.indexOf(socket.username), 1);
            updateUsernames();
        }
        connections.splice(connections.indexOf(socket), 1);
        console.log('Disconnected: %s sockets connected', connections.length);
    });
    pool.query('SELECT * FROM user_table', (error, results) => {
        if (error) {
          throw error;
        }
        results.rows.forEach(row => {
          const username = row.username;
          const password = row.password;
          if (username && password) {
            userStore[username] = { password };
          }
        });
      });

    // Send Message
    socket.on('send message', async function(data){
      if (!socket.username) {
          socket.emit('reload');
      } else {
          var message = {msg: data, user: socket.username};
          chatStore.push(message);
          io.sockets.emit('new message', message);
          await pool.query('INSERT INTO chat_history(content,username) VALUES ($1, $2)', [data,socket.username]);
      }
  });

    // Register User
    socket.on('register', function(data, callback){
        if(userStore[data.username]){
            callback({ success: false, message: 'Username already taken' });
        } else {
            bcrypt.hash(data.password, 10, async function(err, hash) {
                if(err) {
                    callback({ success: false, message: 'Error registering user' });
                } else {
                    userStore[data.username] = { password: hash };
                    await pool.query('INSERT INTO user_table (username, password) VALUES ($1, $2)', [data.username, hash]);
                    callback({ success: true });
                }
            });
        }
    });

    // Login User
    socket.on('login', function(data, callback){
        if(!userStore[data.username]){
            callback({ success: false, message: 'Invalid username or password' });
        } else {
            bcrypt.compare(data.password, userStore[data.username].password, function(err, res) {
                if(res) {
                    socket.username = data.username;
                    users.push(socket.username);
                    updateUsernames();
                    callback({ success: true });
                } else {
                    callback({ success: false, message: 'Invalid username or password' });
                }
            });
        }
    });

    // Logout User
    socket.on('logout', function(callback){
        if(socket.username){
            users.splice(users.indexOf(socket.username), 1);
            updateUsernames();
            socket.username = null;
            callback({ success: true });
        } else {
            callback({ success: false, message: 'No user is currently logged in.' });
        }
    });

    function updateUsernames(){
        io.sockets.emit('get users', users);
    }
});

