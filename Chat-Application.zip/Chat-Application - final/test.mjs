import { connect } from 'socket.io-client';
import { assert } from 'chai';

describe('Chat Scalability', function() {
    this.timeout(600000); // Increase timeout to 10 seconds

    it('should handle 450 users', function(done) {
        let users = Array.from({length: 450}, (_, i) => `user${i}`);
        let clients = users.flatMap(user => [
            connect('http://localhost')
        ]);

        let delay = 0; // Initialize delay
        clients.forEach((client, index) => {
            setTimeout(() => { // Add a delay for each user registration
                client.emit('register', {username: users[index], password: 'password'}, (response) => {
                    try {
                        assert.isTrue(response.success, `Registration failed for user: ${users[index]}`);
                    } catch (error) {
                        console.error('Command failed:', error.message);
                        done(error);
                        return;
                    } 
                    if (index === users.length - 1) {
                        done();
                    }
                });
            }, delay);
            delay += 100; // Increase delay for next user
        });
    });
});